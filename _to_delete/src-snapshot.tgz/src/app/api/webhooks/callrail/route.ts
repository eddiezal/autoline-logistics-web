/**
 * POST /api/webhooks/callrail
 *
 * Receives CallRail call-completed webhook events, validates the HMAC
 * signature, maps to our internal Lead schema, writes to Firestore, and
 * fires a GA4 call_completed event via Measurement Protocol.
 *
 * Auth: CallRail signs every webhook with HMAC-SHA256. The signature is in
 *       the `signature` header. We compute the expected signature from
 *       CALLRAIL_WEBHOOK_SECRET and reject any mismatch.
 *
 * Idempotency: dedupe by CallRail call ID. If we've already written a lead
 *              for this call (e.g. CallRail retried), no-op gracefully.
 *
 * Fire-and-forget side effects:
 *   - Firestore write to `leads` collection with source: "call"
 *   - GA4 call_completed event via Measurement Protocol
 *   - (Future) agent email notification when we wire it in Phase 2
 *
 * Added 2026-06-23 as part of CallRail Phase 1 rollout. See:
 *   CallRail-Kickoff-Plan.md
 *   CallRail-Strategy.md
 */
import { NextResponse } from "next/server";
import crypto from "crypto";
import { FieldValue } from "firebase-admin/firestore";
import { getAdminDb } from "@/lib/firebase/admin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** CallRail post-call webhook payload.
 *  Actual field names captured live via debug mode 2026-07-08.
 *  CallRail sends 100+ fields; these are the ones we care about now.
 *  Everything else is preserved in raw_payload for future extraction. */
interface CallRailPayload {
  /** CallRail's globally unique call ID (used for idempotency).
   *  Note: CallRail's post-call webhook uses `resource_id`, not `id`. */
  resource_id?: string;
  /** Legacy alias in case CallRail also sends this. */
  id?: string;
  /** Source classification (e.g. "Google Paid", "Direct", "google_organic"). */
  source?: string;
  source_name?: string;
  medium?: string;
  /** Caller's phone number. */
  customer_phone_number?: string;
  /** Business line the call routed to. */
  business_phone_number?: string;
  /** The CallRail tracking number the caller dialed (identifies the source pool). */
  tracking_phone_number?: string;
  formatted_tracking_source?: string;
  /** Contact info. */
  customer_name?: string;
  customer_city?: string;
  customer_state?: string;
  customer_country?: string;
  /** ISO timestamp of call start. */
  start_time?: string;
  created_at?: string;
  /** Call duration in seconds. */
  duration?: number | string;
  /** "inbound" or "outbound". */
  direction?: string;
  call_type?: string;
  answered?: boolean | string;
  voicemail?: boolean | string;
  call_disposition?: string;
  first_call?: boolean | string;
  /** Signed URLs for content. */
  recording?: string;
  transcription?: string;
  conversational_transcript?: string;
  /** URL context. */
  landing_page_url?: string;
  referring_url?: string;
  last_requested_url?: string;
  referrer?: string;
  referrer_domain?: string;
  /** UTM params + click IDs (critical for attribution). */
  utm_source?: string;
  utm_medium?: string;
  utm_campaign?: string;
  utm_content?: string;
  utm_term?: string;
  gclid?: string;
  fbclid?: string;
  msclkid?: string;
  /** CallRail AI analysis (Conversation Intelligence tier). */
  keywords?: string;
  keywords_spotted?: string;
  call_summary?: string;
  call_highlights?: string;
  sentiment?: string;
  lead_status?: string;
  lead_score?: number | string;
  lead_explanation?: string;
  /** IDs for auditing. */
  company_id?: string;
  company_resource_id?: string;
  person_id?: string;
  person_resource_id?: string;
  tracker_resource_id?: string;
  /** Any additional fields CallRail sends. */
  [key: string]: unknown;
}

/** Verify the CallRail webhook signature.
 *
 *  Updated 2026-07-08 after debug mode revealed CallRail actually uses
 *  HMAC-SHA1 base64 signing, contradicting the earlier memory that said
 *  it was a plain string comparison. Signatures observed are 28 chars
 *  ending in base64 padding (=), which is HMAC-SHA1's 20-byte output
 *  base64-encoded. The "Signature Secret Token" from CallRail's UI is
 *  used as the HMAC-SHA1 key over the request body.
 *
 *  Timing-safe comparison still used to prevent timing-side-channel
 *  enumeration of the computed hash. */
function verifySignature(
  signature: string | null,
  body: string,
  secret: string,
): boolean {
  if (!signature) return false;
  const computed = crypto
    .createHmac("sha1", secret)
    .update(body)
    .digest("base64");
  const providedBuf = Buffer.from(signature.trim());
  const expectedBuf = Buffer.from(computed);
  if (providedBuf.length !== expectedBuf.length) return false;
  try {
    return crypto.timingSafeEqual(providedBuf, expectedBuf);
  } catch {
    return false;
  }
}

/** Fire a GA4 call_completed event via Measurement Protocol.
 *  Non-blocking — we don't await this in the main flow. */
async function fireGa4Event(payload: CallRailPayload, callId: string): Promise<void> {
  const measurementId = process.env.NEXT_PUBLIC_GA4_MEASUREMENT_ID;
  const apiSecret = process.env.GA4_MEASUREMENT_PROTOCOL_SECRET;
  if (!measurementId || !apiSecret) {
    console.warn("[callrail webhook] GA4 measurement protocol secret not configured; skipping event");
    return;
  }
  // Use the call ID as a stable client_id when we don't have a cookie-based
  // one. This is best-effort attribution; real session-linking will require
  // CallRail's GA4 connector in a later phase.
  const clientId = `callrail.${callId}`;
  const body = {
    client_id: clientId,
    events: [
      {
        name: "call_completed",
        params: {
          call_source: payload.source,
          call_duration_sec: payload.duration ?? 0,
          call_direction: payload.direction ?? "inbound",
          landing_page: payload.landing_page ?? "",
          referrer: payload.referrer ?? "",
          utm_source: payload.utm_source ?? "",
          utm_medium: payload.utm_medium ?? "",
          utm_campaign: payload.utm_campaign ?? "",
          callrail_id: callId,
        },
      },
    ],
  };
  try {
    await fetch(
      `https://www.google-analytics.com/mp/collect?measurement_id=${measurementId}&api_secret=${apiSecret}`,
      {
        method: "POST",
        body: JSON.stringify(body),
      },
    );
  } catch (err) {
    console.error("[callrail webhook] GA4 event fire failed:", err);
  }
}

export async function POST(req: Request) {
  const secret = process.env.CALLRAIL_WEBHOOK_SECRET;
  if (!secret) {
    console.error("[callrail webhook] CALLRAIL_WEBHOOK_SECRET not configured");
    return NextResponse.json(
      { error: "Webhook receiver not configured" },
      { status: 503 },
    );
  }

  const rawBody = await req.text();
  const signature = req.headers.get("signature") ?? req.headers.get("x-callrail-signature");

  const debugMode = process.env.CALLRAIL_WEBHOOK_DEBUG_MODE === "true";
  const sigOk = verifySignature(signature, rawBody, secret);

  if (!sigOk && !debugMode) {
    console.warn("[callrail webhook] signature verification failed", {
      hasSignature: signature !== null,
      providedLen: signature?.length ?? 0,
      expectedLen: secret.length,
      // Log first + last 4 chars of provided signature so we can compare
      // against CallRail's UI without leaking the full token.
      providedPreview: signature
        ? signature.slice(0, 4) + "..." + signature.slice(-4)
        : null,
      expectedPreview: secret.slice(0, 4) + "..." + secret.slice(-4),
    });
    return NextResponse.json({ error: "Invalid signature" }, { status: 401 });
  }

  if (!sigOk && debugMode) {
    console.warn(
      "[callrail webhook] DEBUG MODE ACCEPTING UNVERIFIED: providedLen=" +
        (signature?.length ?? 0) +
        " expectedLen=" +
        secret.length +
        " providedPreview=" +
        (signature ? signature.slice(0, 4) + "..." + signature.slice(-4) : "null") +
        " expectedPreview=" +
        secret.slice(0, 4) +
        "..." +
        secret.slice(-4),
    );
  }

  // CallRail may send either JSON (when configured) or form-encoded (default).
  // Try JSON first, fall back to URLSearchParams parsing.
  let payload: CallRailPayload;
  try {
    payload = JSON.parse(rawBody) as CallRailPayload;
  } catch {
    try {
      const params = new URLSearchParams(rawBody);
      const asObject: Record<string, string> = {};
      for (const [k, v] of params.entries()) asObject[k] = v;
      payload = asObject as unknown as CallRailPayload;
    } catch {
      console.warn(
        "[callrail webhook] body parse failed (neither JSON nor form-encoded): " +
          "bodyLen=" +
          rawBody.length +
          " preview=" +
          rawBody.slice(0, 300),
      );
      return NextResponse.json({ error: "Invalid body format" }, { status: 400 });
    }
  }

  if (debugMode) {
    // Log the raw body + parsed payload keys so we can see exactly what
    // CallRail is sending. Useful when the id lookup fails.
    console.log(
      "[callrail webhook] DEBUG parsed payload: keys=" +
        Object.keys(payload as unknown as Record<string, unknown>).join(",") +
        " id=" +
        (payload as { id?: unknown }).id +
        " bodyLen=" +
        rawBody.length +
        " bodyPreview=" +
        rawBody.slice(0, 400),
    );
  }

  // CallRail post-call webhook uses resource_id as the primary ID.
  // Fall back to id (older schema) or good_lead_call_id (some events).
  const callId =
    (typeof payload.resource_id === "string" ? payload.resource_id : null) ??
    (typeof payload.id === "string" ? payload.id : null) ??
    (typeof (payload as { good_lead_call_id?: unknown }).good_lead_call_id === "string"
      ? String((payload as { good_lead_call_id?: unknown }).good_lead_call_id)
      : null);
  if (!callId) {
    console.warn(
      "[callrail webhook] no resource_id/id field found. bodyLen=" +
        rawBody.length +
        " keys=" +
        Object.keys(payload as unknown as Record<string, unknown>).join(","),
    );
    return NextResponse.json({ error: "Missing call id" }, { status: 400 });
  }

  // Only process inbound calls. Outbound calls are agent-initiated and
  // don't represent leads.
  if (payload.direction && payload.direction !== "inbound") {
    return NextResponse.json({ ok: true, skipped: "outbound" });
  }

  const db = getAdminDb();
  const callDocRef = db.collection("leads").doc(`call_${callId}`);

  // Idempotency check: if this call ID already wrote a lead, no-op.
  // CallRail occasionally retries webhooks on transient failures.
  const existing = await callDocRef.get();
  if (existing.exists) {
    return NextResponse.json({ ok: true, deduped: true });
  }

  const submittedAt = payload.start_time ?? new Date().toISOString();
  const leadDoc = {
    leadRef: `CALL-${callId}`,
    source: "call" as const,
    submittedAt,
    createdAt: FieldValue.serverTimestamp(),
    // Origin / destination / vehicle stay null until agent collects them
    // during the call (Phase 2 post-call outcome capture flow).
    origin: null,
    destination: null,
    vehicle: null,
    tier: null,
    contact: {
      phone: payload.caller_number ?? null,
      email: null,
      notes: null,
    },
    // Assignment happens in CallRail (the call already rang the agent).
    // We do not pre-assign here.
    assignedAgent: null,
    estimate: null,
    callMeta: {
      callrailId: callId,
      calledNumber: payload.called_number ?? null,
      durationSec: payload.duration ?? null,
      recordingUrl: payload.recording ?? null,
      transcriptUrl: payload.transcript ?? null,
      sourcePool: payload.source,
      landingPage: payload.landing_page ?? null,
    },
    attribution: {
      utmSource: payload.utm_source ?? null,
      utmMedium: payload.utm_medium ?? null,
      utmCampaign: payload.utm_campaign ?? null,
      utmContent: payload.utm_content ?? null,
      referrer: payload.referrer ?? null,
    },
    // Status starts as "completed" (the call ended). Agents update with
    // outcome (quoted / booked / lost / unfit) via the Phase 2 dashboard.
    status: "call_completed" as const,
  };

  try {
    await callDocRef.set(leadDoc);
  } catch (err) {
    console.error('[callrail webhook] Firestore write failed:', err);
    return NextResponse.json(
      { error: 'Failed to persist call lead' },
      { status: 500 },
    );
  }

  // Fire GA4 event in the background. Don't block the webhook response
  // on GA4 latency — CallRail expects fast acks.
  fireGa4Event(payload, callId).catch((err) =>
    console.error('[callrail webhook] GA4 background fire failed:', err),
  );

  return NextResponse.json({ ok: true, leadRef: leadDoc.leadRef });
}
